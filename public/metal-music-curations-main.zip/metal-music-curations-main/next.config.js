module.exports = {
  images: {
    domains: ['i.scdn.co'],
  },
  reactStrictMode: true,
}
